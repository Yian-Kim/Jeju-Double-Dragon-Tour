package com.project.jejutvl.randomtravel;

public class Test {
	
	public static void main(String[] args) throws Exception {
		
//		Schedule thisMember = new Schedule("lcedc7151", "");
//		
//		RandomTravel2.start();
		
//		RandomTravel.thisMember();
		//RandomTravel.start();
//		System.out.println(Arrays.toString(RandomTravel.check(condition)));
		
		
	}

}
