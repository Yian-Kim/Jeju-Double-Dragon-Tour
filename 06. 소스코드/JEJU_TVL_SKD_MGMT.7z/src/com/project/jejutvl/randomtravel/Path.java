package com.project.jejutvl.randomtravel;

public class Path {
	
	public static final String schedule;
	public static final String info;
	public static String fakeInfo;	
	public static final String currentMemberId;
	public static final String matching;
	
	static {
		schedule = ".\\data\\더미\\일정더미.dat";
		info = ".\\data\\더미\\회원정보.dat";
		fakeInfo = ".\\data\\FakeSchedule.txt";		
		currentMemberId = "hahaha333";
		matching = ".\\data\\매칭완료.txt";
	}
	
}
