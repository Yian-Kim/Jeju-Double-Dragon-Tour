package com.project.jejutvl.homescreen;

public class Cls {
	
	public static void clearScreen() {
		
		for (int i = 0; i < 50; i++) {
			System.out.println("");
		}
		
	}
	
}
