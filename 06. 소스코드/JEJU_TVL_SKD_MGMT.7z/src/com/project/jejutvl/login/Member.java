package com.project.jejutvl.login;

public class Member {

	private String ID;
	private String password;
	private String name;
	private String year;
	private String gender;
	private String tel;

	public String getID() {
		return ID;
	}

	public void setID(String iD) {
		ID = iD;
	}

	public String getPassword() {
		return password;
	}

	public void setPassword(String password) {
		this.password = password;
	}

	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}

	public String getYear() {
		return year;
	}

	public void setYear(String year) {
		this.year = year;
	}

	public String getGender() {
		return gender;
	}

	public void setGender(String gender) {
		this.gender = gender;
	}

	public String getTel() {
		return tel;
	}

	public void setTel(String tel) {
		this.tel = tel;
	}

	@Override
	public String toString() {
		return "Member [ID=" + ID + ", password=" + password + ", name=" + name + ", year=" + year + ", gender="
				+ gender + ", tel=" + tel + "]";
	}

}
